package org.example;

import spoon.Launcher;
import spoon.reflect.CtModel;
import spoon.reflect.code.CtIf;
import spoon.reflect.code.CtInvocation;
import spoon.reflect.code.CtLiteral;
import spoon.reflect.declaration.CtElement;
import spoon.reflect.declaration.CtMethod;
import spoon.reflect.declaration.CtPackage;

import java.util.HashMap;
import java.util.List;

public class Main
{

	public static void main(String[] args)
	{
		HashMap<Integer, String> menuActionMap = new HashMap<>();
		menuActionMap.put(2, "OPLOCT");
		menuActionMap.put(3, "OPLOC1");
		menuActionMap.put(4, "OPLOC2");
		menuActionMap.put(5, "OPLOC3");
		menuActionMap.put(6, "OPLOC4");
		menuActionMap.put(8, "OPNPCT");
		menuActionMap.put(9, "OPNPC1");
		menuActionMap.put(10, "OPNPC2");
		menuActionMap.put(11, "OPNPC3");
		menuActionMap.put(12, "OPNPC4");
		menuActionMap.put(17, "OPOBJT");
		menuActionMap.put(18, "OPOBJ1");
		menuActionMap.put(19, "OPOBJ2");
		menuActionMap.put(20, "OPOBJ3");
		menuActionMap.put(21, "OPOBJ4");
		menuActionMap.put(15, "OPPLAYERT");
		menuActionMap.put(44, "OPPLAYER1");
		menuActionMap.put(45, "OPPLAYER2");
		menuActionMap.put(46, "OPPLAYER3");
		menuActionMap.put(47, "OPPLAYER4");
		menuActionMap.put(48, "OPPLAYER5");
		menuActionMap.put(49, "OPPLAYER6");
		menuActionMap.put(50, "OPPLAYER7");
		menuActionMap.put(51, "OPPLAYER8");
		menuActionMap.put(58, "IF_BUTTONT");
		HashMap<Integer,String> widgetActionMap = new HashMap<>();
		widgetActionMap.put(1, "IF_BUTTON1");
		widgetActionMap.put(2, "IF_BUTTON2");
		widgetActionMap.put(3, "IF_BUTTON3");
		widgetActionMap.put(4, "IF_BUTTON4");
		widgetActionMap.put(5, "IF_BUTTON5");
		widgetActionMap.put(6, "IF_BUTTON6");
		widgetActionMap.put(7, "IF_BUTTON7");
		widgetActionMap.put(8, "IF_BUTTON8");
		widgetActionMap.put(9, "IF_BUTTON9");
		widgetActionMap.put(10, "IF_BUTTON10");
		Launcher launcher = new Launcher();
		launcher.addInputResource("C:\\Users\\Ethan Vann\\IdeaProjects\\FinalUpdater\\input\\meteor-client-main");
		launcher.getEnvironment().setComplianceLevel(11);
		launcher.buildModel();
		CtModel model = launcher.getModel();
		CtPackage testPackage = (CtPackage) model.getAllPackages().toArray()[0];
		CtMethod menuAction = testPackage.filterChildren(child -> child instanceof CtMethod && ((CtMethod<?>) child).getSimpleName().equals("menuAction")).first();
		menuAction.filterChildren(child -> child instanceof CtIf).forEach(child ->
		{
			CtIf childIf = (CtIf) child;
			CtLiteral<?> condition =
					childIf.getCondition().filterChildren(child1 -> child1 instanceof CtLiteral).first();
			if (condition != null && childIf.getCondition().toString().contains("var") && !condition.toString().equals(
					"null") && menuActionMap.get(Integer.parseInt(condition.toString())) != null)
			{
				List<CtInvocation> invokes = childIf.getThenStatement().filterChildren(invocation -> invocation instanceof CtInvocation).list();
				System.out.println(menuActionMap.get(Integer.parseInt(condition.toString())));
				for (CtInvocation invoke : invokes)
				{
					if (invoke.getTarget().getType().toString().contains("PacketBuffer"))
					{
						System.out.println(invoke);
					}
				}
			}
		});
		CtMethod widgetMethod =
				testPackage.filterChildren(child -> child instanceof CtMethod && ((CtMethod<?>) child).getSimpleName().equals("widgetDefaultMenuAction")).first();
		widgetMethod.filterChildren(child -> child instanceof CtIf).forEach(child ->
		{
			CtIf childIf = (CtIf) child;
			CtLiteral<?> condition =
					childIf.getCondition().filterChildren(child1 -> child1 instanceof CtLiteral).first();
			if (condition != null && childIf.getCondition().toString().contains("var0")&&childIf.getCondition().toString().contains("==") && !condition.toString().equals(
					"null") && widgetActionMap.get(Integer.parseInt(condition.toString())) != null)
			{
				List<CtInvocation> invokes = childIf.getThenStatement().filterChildren(invocation -> invocation instanceof CtInvocation).list();
				System.out.println(widgetActionMap.get(Integer.parseInt(condition.toString())));
				for (CtInvocation invoke : invokes)
				{
					if (invoke.getTarget().getType().toString().contains("PacketBuffer"))
					{
						List<CtElement> invokeChildren = invoke.filterChildren(temp->true).list();
						for (CtElement invokeChild : invokeChildren)
						{
							System.out.println(invokeChild.getClass()+":"+invokeChild);
						}
					}
				}
			}
		});
		System.out.println("EVENT_MOUSE_CLICK");
		CtIf clickIf =
				testPackage.filterChildren(child->child instanceof CtIf && ((CtIf) child).getCondition().toString().contains("shouldProcessClick")).first();
		List<CtInvocation> clickInvokes =
				clickIf.getThenStatement().filterChildren(invocation -> invocation instanceof CtInvocation).list();
		for (CtInvocation invoke : clickInvokes)
		{
			if (invoke.getTarget().getType().toString().contains("PacketBuffer"))
			{
				System.out.println(invoke);
			}
		}
		System.out.println("MOVE_GAMECLICK");
		CtIf walkIf =
				testPackage.filterChildren(child->child instanceof CtIf && ((CtIf) child).getCondition().toString().contains("shouldSendWalk")).first();
		List<CtInvocation> moveInvokes =
				walkIf.getThenStatement().filterChildren(invocation -> invocation instanceof CtInvocation).list();
		for (CtInvocation invoke : moveInvokes)
		{
			if (invoke.getTarget().getType().toString().contains("PacketBuffer"))
			{
				System.out.println(invoke);
			}
		}
		System.out.println("RESUME_PAUSEBUTTON");
		CtMethod resumePause = testPackage.filterChildren(child -> child instanceof CtMethod && ((CtMethod<?>) child).getSimpleName().equals("resumePauseWidget")).first();
		List<CtInvocation> resumePauseInvokes =
				resumePause.getBody().filterChildren(invocation -> invocation instanceof CtInvocation).list();
		for (CtInvocation invoke : resumePauseInvokes)
		{
			if (invoke.getTarget().getType().toString().contains("PacketBuffer"))
			{
				System.out.println(invoke);
			}
		}
	}
}